import argparse
import json
import logging
from typing import List, Dict, Any
from datetime import datetime

from db_connector import MySqlConnector
from etl import EtlWeather

logging.basicConfig(encoding='utf-8', level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__file__)


def __init_argparse() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser()

    parser.add_argument('--host',
                        help='The MySQL host',
                        default='localhost')

    parser.add_argument('--state_file',
                        help='Json state file',
                        default='state.json')

    return parser


def get_state(state_filename: str):
    with open(state_filename) as f:
        content = f.read()
        state = json.loads(content)
    return state


def save_state(state_filename: str, state: List[Dict[str, Any]]):
    with open(state_filename, 'w') as f:
        f.write(json.dumps(state, indent=2))


def main():
    arg_parser = __init_argparse()
    args, _ = arg_parser.parse_known_args()
    host = args.host
    state_file = args.state_file
    logger.info(f'Config ({host=}, {state_file=})')

    state = get_state(state_file)

    connector = MySqlConnector(host)

    for pipeline in state:
        pipeline_name = pipeline['pipeline_name']
        last_ingest = datetime.strptime(pipeline['last_ingest'], '%Y-%m-%dT%H:%M:%S')

        if pipeline_name == 'weather_spider':
            etl = EtlWeather(connector, last_ingest, pipeline_name)
        else:
            raise ValueError(f'Pipeline name {pipeline_name=} not supported')

        last_ingest = etl.process()

        pipeline['last_ingest'] = last_ingest.strftime('%Y-%m-%dT%H:%M:%S')

    save_state(state_file, state)


if __name__ == '__main__':
    main()

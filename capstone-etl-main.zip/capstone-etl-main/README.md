# capstone-etl
ETL for demonstration purpose

## Build image
Then execute this command.

``` bash
docker build -t capstone-etl .
```
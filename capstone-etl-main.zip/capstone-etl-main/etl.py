import csv
import logging
from abc import abstractmethod, ABC
from datetime import datetime, timedelta
from typing import List, Tuple

from mysql.connector import ProgrammingError

from db_connector import MySqlConnector


logger = logging.getLogger(__file__)


class ETL(ABC):
    def __init__(self,
                 db_connect: MySqlConnector,
                 ingest_time: datetime,
                 pipeline_name: str):
        self.db_connect = db_connect
        self.ingest_time = ingest_time
        self.pipeline_name = pipeline_name

    def extract(self):
        sql_stmt = f"SELECT crawl_time, ingest_time, pipeline_name, ingest_key, ingest_value " \
                   f"FROM ingress WHERE ingest_time>'{self.ingest_time}' AND pipeline_name='{self.pipeline_name}'"
        new_rows = self.db_connect.fetchall_query(sql_stmt)
        return new_rows

    @abstractmethod
    def _transform(self,
                   crawl_time: datetime,
                   ingest_time: datetime,
                   pipeline_name: str,
                   ingest_key: str,
                   ingest_value: str):
        raise NotImplementedError

    def transform(self, rows_to_process: List) -> List:
        transformed_rows = []
        for crawl_time, ingest_time, pipeline_name, ingest_key, ingest_value in rows_to_process:
            try:
                transformed_values = self._transform(crawl_time, ingest_time, pipeline_name, ingest_key, ingest_value)
                transformed_rows.append((ingest_time,) + transformed_values)
            except Exception as e:
                error_msg = f'{type(e).__name__}: {e}'.replace('\'', '"')
                self.log_error(ingest_time, ingest_key, ingest_value, error_msg)
        return transformed_rows

    def _load_sql_statement(self, row_to_load: Tuple) -> str:
        raise NotImplementedError

    def load(self, rows_to_load: List):
        last_successful_ingest_time = self.ingest_time
        for ingest_time, *row_to_load in rows_to_load:

            sql_stmt = self._load_sql_statement(row_to_load)
            try:
                self.db_connect.commit_query(sql_stmt)
            except ProgrammingError as e:
                error_msg = f'{type(e).__name__}: {e}'.replace('\'', '"')
                self.log_error(ingest_time, 'sql_stmt', sql_stmt, error_msg)

            # We update the last_successful_ingest_time for both cases (whether it worked or it was logged to error_log)
            if ingest_time > last_successful_ingest_time:
                last_successful_ingest_time = ingest_time

        return last_successful_ingest_time

    def log_error(self, ingest_time: datetime, ingest_key, ingest_value, error_msg):
        sql_stmt = f"INSERT INTO " \
                   f"error_log(ingest_time, error_time, pipeline_name, ingest_key, ingest_value, error_message) " \
                   f"VALUES('{ingest_time}', '{datetime.utcnow()}', '{self.pipeline_name}', " \
                   f"'{ingest_key}', '{ingest_value}', '{error_msg}')"
        self.db_connect.commit_query(sql_stmt)

    def process(self):
        logger.info(f'processing {self.pipeline_name=} {self.ingest_time=}')

        # Extract
        rows = self.extract()

        # Transform
        rows = self.transform(rows)

        # Load
        last_ingest = self.load(rows)

        logger.info(f'processed {len(rows)} rows {last_ingest=}')

        return last_ingest


class EtlWeather(ETL):
    def _transform(self,
                   crawl_time: datetime,
                   ingest_time: datetime,
                   pipeline_name: str,
                   ingest_key: str,
                   ingest_value: str):
        day_number = {
            'Monday': 0,
            'Tuesday': 1,
            'Wednesday': 2,
            'Thursday': 3,
            'Friday': 4,
            'Saturday': 5,
            'Sunday': 6
        }

        csv_reader = csv.reader([ingest_value], quotechar='"', delimiter=',', quoting=csv.QUOTE_ALL)
        values = list(csv_reader)

        city, local_time_str, weather, temperature_str = values[0]

        city = city.split(',')[0]
        local_day = local_time_str.split(' ')[0]
        local_hour_minute = local_time_str.split(' ')[-1]
        local_hour = int(local_hour_minute.split('.')[0])

        # We need to check if UTC and local_time are same day or not
        day_difference = day_number[local_day] - crawl_time.weekday()

        local_time = crawl_time.replace(hour=local_hour) + timedelta(days=day_difference)
        temperature = int(temperature_str)

        return crawl_time, local_time, city, weather, temperature

    def _load_sql_statement(self, row_to_load: Tuple) -> str:
        crawl_time, local_time, city, weather, temperature = row_to_load

        sql_stmt = f"INSERT INTO egress(crawl_time, local_time, city, weather, temperature) " \
                   f"VALUES('{crawl_time}', '{local_time}', '{city}', '{weather}', {temperature})"

        return sql_stmt

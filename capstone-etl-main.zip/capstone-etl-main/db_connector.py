from typing import Any

import mysql.connector  # type: ignore


class MySqlConnector:
    def __init__(self, host: str):
        self.mydb = mysql.connector.connect(
            host=host,
            user="root",
            password="password"
        )

        self.cur = self.mydb.cursor()
        self.cur.execute("USE DB")

    def fetchall_query(self, sql_stmt: str) -> Any:
        self.cur.execute(sql_stmt)
        return self.cur.fetchall()

    def fetch_query(self, sql_stmt: str) -> Any:
        self.cur.execute(sql_stmt)
        return self.cur.fetchone()

    def commit_query(self, sql_stmt: str):
        self.cur.execute(sql_stmt)
        self.mydb.commit()

    def close(self):
        self.cur.close()
        self.mydb.close()

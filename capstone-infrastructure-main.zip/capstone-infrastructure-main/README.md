# capstone-infrastructure
Setting up Infrastructure Example

Build mysql database
``` bash
docker build -t capstone-mysql -f Dockerfile.mysql .
```

## Start them all
``` bash
docker compose up
```